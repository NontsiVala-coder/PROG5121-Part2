/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.prog1apart2;
        
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author theodorav
 */
public class Prog1aPart2UnitTest {
    
    public Prog1aPart2UnitTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

  /**
   * Test of main method of class prog1apart2
   */  
    @Test
    public static void testMain() {
        System.out.println("main");
        String[] args = null;
        Prog1aPart2.main(args);
        //TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
    /**
     * Test of registeredUser method, of class Prog1aPart2.
     */
    @Test
    public void testRegisteredUser() {
        System.out.println("registeredUser");
        Prog1aPart2.registeredUser();
        //TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test the loginUser method, of class Prog1aPart2.
     */
    @Test
    public void testLoginUser() {
    System.out.println("loginUser");
    boolean expResult = false;
    boolean result = Prog1aPart2.loginUser();
    assertEquals(expResult, result);
    //TODO review the generated test code and remove the default call to fail.
    fail("The test case is a prototype.");
    }
    
    /**
     * Test the runMessageSystem method, of class Prog1aPart2.
     */
    @Test
    public void testRunMessageSystem() {
    System.out.println("runMessageSystem");
    Prog1aPart2.runMessageSystem();
    //TODO review the generated test code and remove the default call to fail.
    fail("The test case is a prototype.");
    }
    
    /**
     * Test of sendMessage method, of class Prog1aPart2.
     */
    @Test
    public void testSendMessage() {
    System.out.println("SendMessage");
    Prog1aPart2.sendMessages();
    //TODO review the generated test code and remove the default call to fail.
    fail("The test case is a prototype.");
    }
    
    /**
     * Test of generateMessageID method, of class Prog1aPart2
     */
    @Test
    public void testGenerateMessageID() {
    System.out.println("generateMessageID");
    String expResult = "";
    String result = Prog1aPart2.generateMessageID();
    assertEquals(expResult, result);
    //TODO review the generated test code and remove the default call to fail.
    fail("The test case is a prototype.");
    }
    
    /**
     * Test of generateMessageHash method, of class Prog1aPart2
     */
    @Test
    public void testGenerateMessageHash() {
    System.out.println("generateMessageHash");
    String id = "";
    int num = 0;
    String msg = "";
    String expResult = "";
    String result = Prog1aPart2.generateMessageHash(id, num, msg);
    assertEquals(expResult, result);
    //TODO review the generate test code and remove the default call to fail.
    fail("The test case is a prototype.");
    }
    
    /**
     * Test of displayMessageDetails method, of class Prog1aPart2
     */
    @Test
    public void testDisplayMessageDetails() {
    System.out.println("displayMessageDeatails");
    String id = "";
    String hash = "";
    String recipient = "";
    String message = "";
    Prog1aPart2.displayMessageDetails(id, hash, recipient, message);
    //TODO review the generate test code and remove the default call to fail.
    fail("The test case is a prototype.");
    }
    
    /**
     * Test of writeMessageToJSON method, of class Prog1aPart2
     */
    @Test
    public void testWriteMessageToJSON() {
    System.out.println("writeMessageToJSON");
    String messageID = "";
    String hash = "";
    String recipient = "";
    String message = "";
    Prog1aPart2.writeMessageToJSON(messageID, hash, recipient, message);
    //TODO review the generate test code and remove the default call to fail.
    fail("The test case is a prototype.");
    }
}
